# vim-haskell

A vim configuration for use with [pathogen](https://github.com/tpope/vim-pathogen).

## Authorship

The original authors listed in the scripts are Claus Reinke , motemen <motemen@gmail.com>, John Williams <jrw@pobox.com>

In addition, the syntax file has the following note:

    Thanks to Ryan Crumley for suggestions and John Meacham for
    pointing out bugs. Also thanks to Ian Lynagh and Donald Bruce Stewart
    for providing the inspiration for the inclusion of the handling
    of C preprocessor directives, and for pointing out a bug in the
    end-of-line comment handling.

