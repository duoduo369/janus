# vim-node.js
Copyright (C) 2011 by Maciej Małecki  
MIT License (see LICENSE file)

vim-node.js is a file type detect plugin for vim which detects node.js shebang
and sets file type to JavaScript.

