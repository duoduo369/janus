<img src="http://ap.github.io/vim-css-color/screenshot.png" alt=""/>

A very fast fork of [Niklas Hofer’s `css_color.vim`](http://www.vim.org/scripts/script.php?script_id=2150), with extra features:

* multiple color highlights per line
* `rgb()`, `rgba()`, [`hsl()`](http://www.w3.org/TR/css3-color/#hsl-color) support

Inspired by [Max Vasiliev’s fork](https://github.com/skammer/vim-css-color).
