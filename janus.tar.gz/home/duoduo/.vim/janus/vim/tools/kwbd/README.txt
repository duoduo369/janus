Thanks to
http://vim.wikia.com/wiki/Deleting_a_buffer_without_closing_the_window
