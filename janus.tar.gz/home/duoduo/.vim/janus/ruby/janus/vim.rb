module Janus
  module VIM
    extend self

    # Folders
    def folders
      %w[ _backup _temp ]
    end
  end
end
